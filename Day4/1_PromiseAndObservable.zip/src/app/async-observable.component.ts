import { Component, OnInit } from '@angular/core';
import { Observable, interval, from } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
    selector: 'async-observable',
    template: `
        <h2 class="text-info">With Promise</h2>
        <h3>Result: {{observableData}}</h3>
        <h3>Observable Result: {{ observableResult | async}}</h3>
    `
})

export class AsyncObservableComponent implements OnInit {
    observableData: number;
    observableResult: Observable<number>;

    constructor() { }

    ngOnInit() {
        this.getObservable().subscribe(n => this.observableData = n);
        this.observableResult = this.getObservable();
    }

    getObservable(): Observable<number> {
        return interval(2000).pipe(map(v => Math.random()));
    }
}