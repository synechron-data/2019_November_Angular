import { Component, OnInit, AfterViewInit, OnDestroy } from '@angular/core';
import { Observable, Observer, Subject, Subscription } from 'rxjs';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Promise & Observable</h1>
            </div>

            <async-promise></async-promise>
            <br/><br/>
            <async-observable></async-observable>
        </div>
    `
})

export class RootComponent implements OnInit, OnDestroy {

    observable: Observable<number>;
    subject: Subject<number>;

    sOne: Subscription;
    sTwo: Subscription;


    constructor() {
    }

    ngOnInit() {
        // this.subject = new Subject<number>();

        // setInterval(() => {
        //     this.subject.next(Math.random());
        // }, 2000);

        // this.sOne = this.subject.subscribe((data) => {
        //     console.log("S1, Output - ", data);
        // });

        // this.sTwo = this.subject.subscribe((data) => {
        //     console.log("S2, Output - ", data);
        // });

        // this.observable = Observable.create((ob: Observer<number>) => {
        //     setInterval(function () {
        //         // console.log("Inside Observable....");
        //         ob.next(Math.random());
        //     }, 2000);
        // });

        // this.observable.subscribe((data)=>{
        //     console.log("Observer 1 Output -", data);
        // });

        // this.observable.subscribe((data)=>{
        //     console.log("Observer 2 Output -", data);
        // });

        // this.getPromise().then((data) => {
        //     console.log("Promise Output - ", data);
        // }, (err) => {
        //     console.log(err);
        // })
    }

    ngOnDestroy(): void {
        this.sOne.unsubscribe();
        this.sTwo.unsubscribe();
    }

    getPromise(): Promise<number> {
        return new Promise((resolve, reject) => {
            setInterval(function () {
                resolve(Math.random());
            }, 2000);
        });
    }
}