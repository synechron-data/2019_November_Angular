import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";

import { RootComponent } from "./components/root/root.component";
import { BSNavigationComponent } from "./components/bs-nav/bs-nav.component";
import { RouterModule, PreloadAllModules, NoPreloading } from "@angular/router";
import { routes } from "./app.routes";
import { HomeComponent } from "./components/home/home.component";
import { AboutComponent } from "./components/about/about.component";
import { APP_BASE_HREF } from "@angular/common";
import { AuthorsModule } from "./authors-module/authors.module";
import { ProductsComponent } from "./components/products/products.component";
import { NotFoundComponent } from "./components/not-found/not-found.component";
import { ProductNotSelectedComponent } from "./components/products/ns.component";
import { ProductDetailsComponent } from "./components/products/pd.component";
import { AdminComponent } from "./components/admin/admin.component";
import { LoginComponent } from "./components/login/login.component";
import { AuthGuardService } from "./services/auth-gaurd.service";
import { AuthenticationService } from "./services/authentication.service";
import { TokenInterceptorService } from "./services/token-interceptor.service";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule,
        RouterModule.forRoot(routes), AuthorsModule],
    declarations: [RootComponent, BSNavigationComponent, HomeComponent,
        AboutComponent, NotFoundComponent,
        ProductsComponent, ProductNotSelectedComponent, ProductDetailsComponent,
        AdminComponent, LoginComponent
    ],
    bootstrap: [RootComponent],
    providers: [
        AuthenticationService,
        AuthGuardService,
        {
            provide: APP_BASE_HREF,
            useValue: '/'
        },
        {
            provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
                return (component: ComponentRef<any>) => {
                    console.log(component);
                }
            }
        },
        {
            provide: HTTP_INTERCEPTORS,
            multi: true,
            useClass: TokenInterceptorService
        },
    ]
})
export class AppModule {

}