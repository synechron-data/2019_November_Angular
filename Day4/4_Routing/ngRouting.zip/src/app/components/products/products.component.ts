import { Component, OnInit } from '@angular/core';
import { Product } from '../../models/product.model';
import { ProductService } from '../../services/product.service';

@Component({
    styleUrls: ['./products.component.css'],
    templateUrl: 'products.component.html',
    providers: [ProductService]
})

export class ProductsComponent implements OnInit {
    productsList: Array<Product>;

    constructor(private _pService: ProductService) { }

    ngOnInit() {
        this.productsList = this._pService.Products;
    }
}