import { Component, OnInit } from '@angular/core';
import { Post } from './models/post.model';
import { PostService } from './services/post.service';

@Component({
    selector: 'root',
    templateUrl: './root.component.html',
    providers: [PostService]
})

export class RootComponent implements OnInit {
    posts: Array<Post>;
    message: string;
    url: string;

    constructor(private pService: PostService) {
        this.url = "";
        this.message = "Loading Data, please wait...";
    }

    ngOnInit() {
        this.pService.getPosts().subscribe((resData) => {
            this.posts = resData;
            this.message = "";
        }, (err: string) => {
            this.message = err;
        });
    }
}

// import { Component, OnInit } from '@angular/core';
// import { HttpClient, HttpErrorResponse } from "@angular/common/http";
// import { Post } from './models/post.model';

// @Component({
//     selector: 'root',
//     templateUrl: './root.component.html'
// })

// export class RootComponent implements OnInit {
//     posts: Array<Post>;
//     message: string;
//     url: string;

//     constructor(private httpClient: HttpClient) {
//         this.url = "https://jsonplaceholder.typicode.com/posts";
//         this.message = "Loading Data, please wait...";
//     }

//     ngOnInit() {
//         this.httpClient.get<Array<Post>>(this.url).subscribe((resData) => {
//             this.posts = resData;
//             this.message = "";
//         }, (err: HttpErrorResponse) => {
//             this.message = err.message;
//         });
//     }
// }