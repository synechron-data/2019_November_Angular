import { NgModule, APP_BOOTSTRAP_LISTENER, ComponentRef } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { RootComponent } from "./root.component";
import { FormsModule } from "@angular/forms";
import { AssignOneComponent } from "./assign-one/assign-one.component";
import { AssignTwoComponent } from "./assign-two/assign-two.component";
import { ListComponent } from "./list/list.component";
import { ChangeContentDirective } from "./directives/change-content.directive";
import { HighlightDirective } from "./directives/highlight.directive";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, HighlightDirective, ChangeContentDirective, ListComponent, AssignOneComponent, AssignTwoComponent],
    bootstrap: [RootComponent],
    providers: [{
        provide: APP_BOOTSTRAP_LISTENER, multi: true, useFactory: () => {
            return (component: ComponentRef<any>) => {
                console.log(component);
            }
        }
    }]
})
export class AppModule {

}