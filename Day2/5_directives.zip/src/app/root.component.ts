import { Component, OnInit, ChangeDetectionStrategy, AfterViewInit, NgZone } from '@angular/core';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Directives</h1>
            </div>

            <div [hidden]="flag">
                <h2>Custom Directive</h2>
                <h3 change-content></h3>
                <list></list>
            </div>

            <div [hidden]="!flag">
                <h2>Structural Directive</h2>

                <list></list>

                <h4 [style.display]="name?'block':'none'">
                    Hi, {{name}}
                </h4>

                <ng-template [ngIf]="name">
                    <h4>
                        Hi, {{name}}
                    </h4>
                </ng-template>

                <h4 *ngIf="name">
                    Hi, {{name}}
                </h4>
            </div>

            <div [hidden]=!flag>
                <h2>Attribute Directive</h2>
                <h4 [ngStyle]="myStyles">
                    Style Binding
                </h4>
                <assign-two></assign-two>
            </div>

        </div>
    `
})

export class RootComponent implements OnInit {
    flag: boolean;
    name: string;
    myStyles = {
        'background-color': 'green',
        'font-size': '20px',
        'color': 'white'
    };

    constructor(private zone: NgZone) {
        // this.name = "Synechron";
        this.flag = false;
    }

    ngOnInit() { }
}