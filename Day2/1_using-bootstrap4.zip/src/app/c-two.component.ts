import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-two',
    template: `
        <h1 class="text-success">Hello from Component Two!</h1>
    `
})

export class CTwoComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}