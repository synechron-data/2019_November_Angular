import { Component, OnInit, ChangeDetectionStrategy, AfterViewInit, NgZone, ViewChild, QueryList, ViewChildren } from '@angular/core';
import { CounterComponent } from './counter/counter.component';

@Component({
    selector: 'root',
    template: `
        <div class="container">
            <div class="row">
                <h1 class="text-info">Communication</h1>
            </div>

            <div [hidden]=flag>
                <h3 class="alert alert-danger" *ngIf=message>{{message}}</h3>
                <counter #c1 (maxedOut)="onMax($event)" [(pflag)]="ptest"></counter>
                <br/>
                <div class="col-md-2">
                    <button [disabled]="!ptest" class="btn btn-warning btn-block" (click)="c1.reset()">Parent Reset</button>
                </div>
            </div>

            <!-- <div [hidden]=!flag>
                <counter #c1></counter>
                <counter #c2></counter>
                <br/>
                <div class="row">
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="c1.reset()">Parent Reset</button>
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-warning btn-block" (click)="p_reset(c1)">Parent Reset</button>
                    </div>
                </div>
            </div> -->

            <div [hidden]=!flag>
                <counter></counter>
                <!-- <counter [interval]=5></counter> -->
            </div>

        </div>
    `
})

export class RootComponent implements OnInit, AfterViewInit {
    // @ViewChild(CounterComponent)
    // counter: CounterComponent;

    // @ViewChild("c2")
    // counter: CounterComponent;

    // @ViewChildren(CounterComponent)
    // counters: QueryList<CounterComponent>;

    message: string;
    flag: boolean;
    ptest: boolean;

    constructor(private zone: NgZone) {
        this.flag = false;
        this.message = "";
    }

    ngOnInit() { }

    p_reset(c: CounterComponent) {
        c.reset();
    }

    ngAfterViewInit(): void {
        // this.counter.interval = 100;
        // for (const counter of this.counters.toArray()) {
        //     counter.interval = 100;
        // }
    }

    onMax(flag: boolean) {
        if (flag)
            this.message = "Max Click Reached, please reset to continue...";
        else
            this.message = "";
    }

    doChange(v:boolean){
        console.log(v);
        this.ptest = v;
    }
}