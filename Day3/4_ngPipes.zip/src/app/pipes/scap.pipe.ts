import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'scap'
})

export class ShowCaptionPipe implements PipeTransform {
    transform(value: boolean, ...args: any[]): any {
        if(value)
            return "Short Date";
        else
            return "Full Date";
    }
}