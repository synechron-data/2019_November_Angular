import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl, ValidatorFn } from '@angular/forms';

// function ageRangeValidator(control: AbstractControl): { [key: string]: boolean } | null {
//     if (!control.value) {
//         return null;
//     }

//     if (control.value !== undefined && (isNaN(control.value) || control.value < 18 || control.value > 60)) {
//         return { 'ageRange': true };
//     }
// }

function ageRangeValidator(min: number, max: number): ValidatorFn {
    return function (control: AbstractControl): { [key: string]: boolean } | null {
        if (!control.value) {
            return null;
        }

        if (control.value !== undefined && (isNaN(control.value) || control.value < min || control.value > max)) {
            return { 'ageRange': true };
        }
    }
}

@Component({
    selector: 'validation-form',
    templateUrl: 'validation-form.component.html'
})

export class ValidationFormComponent implements OnInit {
    countries = [
        { 'id': "", 'name': 'Select Country' },
        { 'id': 1, 'name': 'India' },
        { 'id': 2, 'name': 'USA' },
        { 'id': 3, 'name': 'UK' }
    ];

    minAge = 20;
    maxAge = 60;

    regForm: FormGroup;

    constructor(private frmBuilder: FormBuilder) { }

    get frm() { return this.regForm.controls; }
    get address() { return (<FormGroup>this.regForm.controls.address).controls; }

    ngOnInit() {
        this.regForm = this.frmBuilder.group({
            firstname: ["", Validators.required],
            lastname: ["", Validators.compose([
                Validators.required,
                Validators.minLength(2),
                Validators.maxLength(6)
            ])],
            age: ["", [
                Validators.required,
                // ageRangeValidator
                ageRangeValidator(this.minAge, this.maxAge)
            ]],
            address: this.frmBuilder.group({
                country: ["", Validators.required],
                city: ["", Validators.required],
                zip: [0, Validators.required]
            })
        }, { updateOn: 'submit' });
    }

    private markAllAsTouched(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            if (control instanceof FormControl) {
                control.markAsTouched();
            } else if (control instanceof FormGroup) {
                this.markAllAsTouched(control);
            }
        });
    }

    logForm() {
        if (this.regForm.valid)
            console.log(this.regForm.value);
        else {
            this.markAllAsTouched(this.regForm);
            console.log("Invalid Data...");
        }
    }
}