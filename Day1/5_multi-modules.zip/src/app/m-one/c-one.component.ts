import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'c-one',
    template: `
        <h1 class="text-info">Hello from Component One - Module One!</h1>
    `
})

export class COneComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}